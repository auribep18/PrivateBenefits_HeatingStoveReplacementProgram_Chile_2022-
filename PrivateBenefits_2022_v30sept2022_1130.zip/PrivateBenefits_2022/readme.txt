Data and code for: Private Benefits from Ambient Air Pollution Reduction Policies: Evidence from the Household Heating Stove Replacement Program in Chile 

Adolfo Uribe (Programa de Doctorado en Econom�a, Universidad de Talca, Chile)
Carlos Ch�vez (Facultad de Econom�a y Negocios, Universidad de Talca, Chile)
Walter G�mez (Departamento de Ingenier�a Matem�tica, Universidad de La Frontera, Chile)
Marcela Jaime (Escuela de Administraci�n y Negocios, Universidad de Concepci�n and Center of Applied Ecology and Sustainability (CAPES), Chile)
Randy Bluffstone (Department of Economics, Portland State University, USA)

Address correspondence to: Carlos Ch�vez (E-mail: cchavez@utalca.cl.)

Acknowledgements: 
This research has been conducted under an agreement of collaboration between Universidad de Talca and the Ministry of Environment, Government of Chile. 
We would like to thank Rodrigo Fica and Andrea Brevis at the Regional Office of the Ministry of Environment, Government of Chile 
for useful discussions and support during early stages of the research design and fieldwork. 
We gratefully acknowledge financial support for this research from the Swedish International Development Cooperation Agency (Sida) 
through the Environment for Development (EfD) Initiative at the University of Gothenburg under project EfD MS-823 
�Evaluating Environmental Policies. The Impacts of Stove Programs in Urban Households of Central-Southern Chile�.

**************************************************************************************************

1_surveys_and_logginsforms:

1. LogginForm_Firewood_Spanish

2. LogginForm_Pellet_Spanish



**************************************************************************************************

2_data:

1. 

2. 


**************************************************************************************************

3_code:

1. 

2. 


**************************************************************************************************

4_output:

1. 

2. 


**************************************************************************************************

5_photos:

1. 

2. 


**************************************************************************************************
